import tkinter as tk
from tkinter import messagebox
from datetime import datetime
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure


# ==========================================
# APPLICATION CONFIGURATION
# ==========================================

APP_NAME = "Fase4EstebanAmaya"
STUDENT_NAME = "Esteban Jesus Amaya Orozco"
COURSE_NAME = "Data Structures"
COURSE_CODE = "301305"
PASSWORD = "UNAD"

BACKGROUND = "#0B1120"
CARD_COLOR = "#151F32"
ACCENT = "#06B6D4"
TEXT = "#E2E8F0"
SECONDARY = "#94A3B8"
INPUT_COLOR = "#1E293B"
GREEN = "#34D399"
PURPLE = "#A78BFA"

MAX_LEVELS = 4

root = tk.Tk()
root.title("BST Explorer")
root.geometry("850x650")
root.configure(bg=BACKGROUND)
root.resizable(False, False)

tree_root = None
tree_values = []


# ==========================================
# BINARY SEARCH TREE
# ==========================================

class TreeNode:

    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def insert_node(node, value):

    if node is None:
        return TreeNode(value)

    if value < node.value:
        node.left = insert_node(node.left, value)

    elif value > node.value:
        node.right = insert_node(node.right, value)

    return node


def search_node(node, value):

    if node is None:
        return False

    if node.value == value:
        return True

    if value < node.value:
        return search_node(node.left, value)

    return search_node(node.right, value)


def preorder(node):

    if node is None:
        return []

    return [node.value] + preorder(node.left) + preorder(node.right)


def inorder(node):

    if node is None:
        return []

    return inorder(node.left) + [node.value] + inorder(node.right)


def postorder(node):

    if node is None:
        return []

    return postorder(node.left) + postorder(node.right) + [node.value]


def get_tree_height(node):

    if node is None:
        return 0

    return 1 + max(
        get_tree_height(node.left),
        get_tree_height(node.right)
    )


# Calculate the level where a new node would be inserted

def get_insertion_depth(node, value, depth=1):

    if node is None:
        return depth

    if value < node.value:
        return get_insertion_depth(
            node.left,
            value,
            depth + 1
        )

    return get_insertion_depth(
        node.right,
        value,
        depth + 1
    )


# ==========================================
# LOGIN WINDOW
# ==========================================

def access_application():

    if password_entry.get() == PASSWORD:

        root.withdraw()
        open_main_window()

    else:

        messagebox.showerror(
            "Access Denied",
            "Incorrect password. Please try again."
        )

        password_entry.delete(0, tk.END)


def toggle_password():

    if password_entry.cget("show") == "*":

        password_entry.config(show="")
        visibility_button.config(text="Hide")

    else:

        password_entry.config(show="*")
        visibility_button.config(text="Show")


main_frame = tk.Frame(
    root,
    bg=CARD_COLOR,
    highlightbackground=ACCENT,
    highlightthickness=1
)

main_frame.place(
    relx=0.5,
    rely=0.5,
    anchor="center",
    width=560,
    height=540
)

tk.Label(
    main_frame,
    text="◈  BST EXPLORER",
    font=("Segoe UI", 27, "bold"),
    bg=CARD_COLOR,
    fg=ACCENT
).pack(pady=(35, 5))

tk.Label(
    main_frame,
    text="BINARY SEARCH TREE | PHASE 4",
    font=("Segoe UI", 10, "bold"),
    bg=CARD_COLOR,
    fg=SECONDARY
).pack(pady=(0, 30))


info_frame = tk.Frame(
    main_frame,
    bg=INPUT_COLOR
)

info_frame.pack(padx=45, fill="x", pady=5)

information = [
    ("APPLICATION", APP_NAME),
    ("STUDENT", STUDENT_NAME),
    ("COURSE", COURSE_NAME),
    ("COURSE CODE", COURSE_CODE),
    ("DATE", datetime.now().strftime("%B %d, %Y"))
]

for label_text, value_text in information:

    row = tk.Frame(info_frame, bg=INPUT_COLOR)
    row.pack(fill="x", padx=15, pady=9)

    tk.Label(
        row,
        text=label_text,
        font=("Segoe UI", 9, "bold"),
        bg=INPUT_COLOR,
        fg=ACCENT,
        width=15,
        anchor="w"
    ).pack(side="left")

    tk.Label(
        row,
        text=value_text,
        font=("Segoe UI", 9),
        bg=INPUT_COLOR,
        fg=TEXT,
        anchor="w"
    ).pack(side="left")


tk.Label(
    main_frame,
    text="ENTER ACCESS PASSWORD",
    font=("Segoe UI", 10, "bold"),
    bg=CARD_COLOR,
    fg=TEXT
).pack(anchor="w", padx=48, pady=(25, 10))


password_frame = tk.Frame(
    main_frame,
    bg=INPUT_COLOR,
    highlightbackground=ACCENT,
    highlightthickness=1
)

password_frame.pack(padx=45, fill="x")

password_entry = tk.Entry(
    password_frame,
    font=("Segoe UI", 15),
    bg=INPUT_COLOR,
    fg=TEXT,
    insertbackground=ACCENT,
    show="*",
    relief="flat"
)

password_entry.pack(
    side="left",
    fill="x",
    expand=True,
    padx=15,
    pady=13
)

visibility_button = tk.Button(
    password_frame,
    text="Show",
    command=toggle_password,
    font=("Segoe UI", 9, "bold"),
    bg=INPUT_COLOR,
    fg=ACCENT,
    relief="flat",
    cursor="hand2"
)

visibility_button.pack(side="right", padx=12)

tk.Label(
    main_frame,
    text="Your password is protected.",
    font=("Segoe UI", 9),
    bg=CARD_COLOR,
    fg=SECONDARY
).pack(anchor="w", padx=48, pady=8)

tk.Button(
    main_frame,
    text="ACCESS BST EXPLORER  →",
    command=access_application,
    font=("Segoe UI", 11, "bold"),
    bg=ACCENT,
    fg="#08111F",
    relief="flat",
    cursor="hand2",
    height=2
).pack(fill="x", padx=45, pady=(20, 15))

tk.Label(
    main_frame,
    text="UNAD | SCHOOL OF ENGINEERING",
    font=("Segoe UI", 8, "bold"),
    bg=CARD_COLOR,
    fg="#64748B"
).pack(pady=5)


# ==========================================
# MAIN WINDOW
# ==========================================

def open_main_window():

    global tree_root, tree_values

    window = tk.Toplevel(root)
    window.title("BST Explorer - Main Dashboard")
    window.geometry("1250x850")
    window.configure(bg=BACKGROUND)
    window.minsize(1050, 750)

    def close_application():

        if messagebox.askyesno(
            "Exit Application",
            "Are you sure you want to exit?"
        ):

            window.destroy()
            root.destroy()

    window.protocol("WM_DELETE_WINDOW", close_application)

    # Header

    header = tk.Frame(
        window,
        bg=CARD_COLOR,
        height=75
    )

    header.pack(fill="x")
    header.pack_propagate(False)

    tk.Label(
        header,
        text="◈ BST EXPLORER",
        font=("Segoe UI", 20, "bold"),
        bg=CARD_COLOR,
        fg=ACCENT
    ).pack(side="left", padx=25, pady=15)

    tk.Label(
        header,
        text="BINARY SEARCH TREE VISUALIZATION",
        font=("Segoe UI", 10, "bold"),
        bg=CARD_COLOR,
        fg=SECONDARY
    ).pack(side="right", padx=25)

    # Main content

    content = tk.Frame(
        window,
        bg=BACKGROUND
    )

    content.pack(
        fill="both",
        expand=True,
        padx=18,
        pady=15
    )

    # Control panel

    control = tk.Frame(
        content,
        bg=CARD_COLOR,
        width=240
    )

    control.pack(
        side="left",
        fill="y",
        padx=(0, 15)
    )

    control.pack_propagate(False)

    tk.Label(
        control,
        text="TREE CONTROLS",
        font=("Segoe UI", 14, "bold"),
        bg=CARD_COLOR,
        fg=ACCENT
    ).pack(pady=(25, 25))

    tk.Label(
        control,
        text="ENTER INTEGER VALUE",
        font=("Segoe UI", 9, "bold"),
        bg=CARD_COLOR,
        fg=TEXT
    ).pack(anchor="w", padx=18)

    value_entry = tk.Entry(
        control,
        font=("Segoe UI", 15),
        bg=INPUT_COLOR,
        fg=TEXT,
        insertbackground=ACCENT,
        relief="flat",
        justify="center"
    )

    value_entry.pack(
        fill="x",
        padx=18,
        pady=12,
        ipady=10
    )

    status_label = tk.Label(
        control,
        text="Ready to build your tree",
        font=("Segoe UI", 9),
        bg=CARD_COLOR,
        fg=SECONDARY,
        wraplength=200
    )

    status_label.pack(pady=10)

    # Drawing area

    display = tk.Frame(
        content,
        bg=CARD_COLOR
    )

    display.pack(
        side="left",
        fill="both",
        expand=True
    )

    # Tree visualization

    tree_panel = tk.Frame(
        display,
        bg=INPUT_COLOR
    )

    tree_panel.pack(
        fill="both",
        expand=True,
        padx=10,
        pady=10
    )

    tk.Label(
        tree_panel,
        text="BINARY SEARCH TREE",
        font=("Segoe UI", 13, "bold"),
        bg=INPUT_COLOR,
        fg=ACCENT
    ).pack(pady=8)

    figure = Figure(
        figsize=(8, 4),
        dpi=100,
        facecolor=INPUT_COLOR
    )

    tree_canvas = FigureCanvasTkAgg(
        figure,
        master=tree_panel
    )

    tree_canvas.get_tk_widget().pack(
        fill="both",
        expand=True
    )

    # Traversal panels

    traversal_frame = tk.Frame(
        display,
        bg=CARD_COLOR
    )

    traversal_frame.pack(
        fill="x",
        padx=10,
        pady=(0, 10)
    )

    traversal_data = {}

    traversal_colors = [
        ACCENT,
        GREEN,
        PURPLE
    ]

    traversal_names = [
        "PREORDER",
        "INORDER",
        "POSTORDER"
    ]

    for index, name in enumerate(traversal_names):

        panel = tk.Frame(
            traversal_frame,
            bg=INPUT_COLOR,
            height=105
        )

        panel.pack(
            side="left",
            fill="both",
            expand=True,
            padx=5
        )

        tk.Label(
            panel,
            text=name,
            font=("Segoe UI", 10, "bold"),
            bg=INPUT_COLOR,
            fg=traversal_colors[index]
        ).pack(pady=(12, 8))

        result = tk.Label(
            panel,
            text="Empty",
            font=("Segoe UI", 10, "bold"),
            bg=INPUT_COLOR,
            fg=TEXT,
            wraplength=190
        )

        result.pack(padx=5)

        traversal_data[name] = result

    # Statistics

    statistics = tk.Frame(
        display,
        bg=CARD_COLOR
    )

    statistics.pack(fill="x", pady=5)

    stats_label = tk.Label(
        statistics,
        text="NODES: 0     |     LEVELS: 0 / 4",
        font=("Segoe UI", 10, "bold"),
        bg=CARD_COLOR,
        fg=ACCENT
    )

    stats_label.pack(pady=8)

    # Update tree display

    def update_visualization():

        figure.clear()

        ax = figure.add_subplot(111)
        ax.set_facecolor(INPUT_COLOR)

        if tree_root is None:

            ax.text(
                0.5,
                0.5,
                "YOUR TREE WILL APPEAR HERE",
                ha="center",
                va="center",
                color=SECONDARY,
                fontsize=13
            )

            ax.axis("off")

        else:

            def draw(node, x, y, dx):

                if node is None:
                    return

                if node.left:

                    ax.plot(
                        [x, x - dx],
                        [y, y - 1],
                        color=ACCENT,
                        linewidth=2
                    )

                    draw(
                        node.left,
                        x - dx,
                        y - 1,
                        dx / 2
                    )

                if node.right:

                    ax.plot(
                        [x, x + dx],
                        [y, y - 1],
                        color=ACCENT,
                        linewidth=2
                    )

                    draw(
                        node.right,
                        x + dx,
                        y - 1,
                        dx / 2
                    )

                ax.scatter(
                    x,
                    y,
                    s=950,
                    color="#164E63",
                    edgecolors=ACCENT,
                    linewidths=2,
                    zorder=3
                )

                ax.text(
                    x,
                    y,
                    str(node.value),
                    ha="center",
                    va="center",
                    color="white",
                    fontsize=10,
                    fontweight="bold",
                    zorder=4
                )

            draw(
                tree_root,
                0,
                0,
                4
            )

            ax.set_xlim(-8, 8)
            ax.set_ylim(-4.5, 1)
            ax.axis("off")

        figure.tight_layout()
        tree_canvas.draw()

        traversal_data["PREORDER"].config(
            text=" → ".join(map(str, preorder(tree_root))) or "Empty"
        )

        traversal_data["INORDER"].config(
            text=" → ".join(map(str, inorder(tree_root))) or "Empty"
        )

        traversal_data["POSTORDER"].config(
            text=" → ".join(map(str, postorder(tree_root))) or "Empty"
        )

        height = get_tree_height(tree_root)

        stats_label.config(
            text=f"NODES: {len(tree_values)}     |     LEVELS: {height} / {MAX_LEVELS}"
        )

    # ======================================
    # ADD NODE - CORRECTED VALIDATION
    # ======================================

    def add_node():

        global tree_root

        try:

            value = int(value_entry.get())

        except ValueError:

            messagebox.showerror(
                "Invalid Input",
                "Please enter an integer number."
            )

            value_entry.delete(0, tk.END)
            return

        if value in tree_values:

            messagebox.showwarning(
                "Duplicate Node",
                "This value already exists in the tree."
            )

            return

        # Check the insertion level BEFORE adding the node

        if tree_root is not None:

            insertion_depth = get_insertion_depth(
                tree_root,
                value
            )

            if insertion_depth > MAX_LEVELS:

                messagebox.showerror(
                    "Maximum Levels",
                    "Cannot insert this node.\n\n"
                    "The binary search tree cannot exceed "
                    "four levels."
                )

                status_label.config(
                    text="Maximum of four levels reached.",
                    fg="#F87171"
                )

                value_entry.delete(0, tk.END)
                return

        # Insert the node only after validation

        tree_root = insert_node(
            tree_root,
            value
        )

        tree_values.append(value)

        update_visualization()

        status_label.config(
            text=f"Node {value} added successfully.",
            fg=GREEN
        )

        value_entry.delete(0, tk.END)

    # Search node

    def find_node():

        try:

            value = int(value_entry.get())

        except ValueError:

            messagebox.showerror(
                "Invalid Input",
                "Please enter an integer number."
            )

            return

        if search_node(tree_root, value):

            messagebox.showinfo(
                "Node Found",
                f"Node {value} exists in the tree."
            )

            status_label.config(
                text=f"Node {value} found.",
                fg=GREEN
            )

        else:

            messagebox.showwarning(
                "Node Not Found",
                f"Node {value} does not exist in the tree."
            )

            status_label.config(
                text="Node not found.",
                fg="#F87171"
            )

    # Clear tree

    def clear_tree():

        global tree_root, tree_values

        if messagebox.askyesno(
            "Clear Tree",
            "Do you want to remove all nodes?"
        ):

            tree_root = None
            tree_values = []

            update_visualization()

            status_label.config(
                text="Tree cleared successfully.",
                fg=GREEN
            )

    # Buttons

    buttons = [
        ("ADD NODE  +", add_node, ACCENT),
        ("SEARCH NODE  ⌕", find_node, "#2563EB"),
        ("CLEAR TREE  ↻", clear_tree, "#7C3AED"),
        ("EXIT APPLICATION  ✕", close_application, "#DC2626")
    ]

    for text, command, color in buttons:

        tk.Button(
            control,
            text=text,
            command=command,
            font=("Segoe UI", 10, "bold"),
            bg=color,
            fg="white",
            activebackground=color,
            activeforeground="white",
            relief="flat",
            cursor="hand2",
            height=2
        ).pack(
            fill="x",
            padx=18,
            pady=8
        )

    update_visualization()


# ==========================================
# APPLICATION EXECUTION
# ==========================================

root.bind(
    "<Return>",
    lambda event: access_application()
)

password_entry.focus()

root.mainloop()